<?php

namespace App\Services\Contracts;

interface VilleServiceInterface extends BaseServiceInterface
{
    //
}
