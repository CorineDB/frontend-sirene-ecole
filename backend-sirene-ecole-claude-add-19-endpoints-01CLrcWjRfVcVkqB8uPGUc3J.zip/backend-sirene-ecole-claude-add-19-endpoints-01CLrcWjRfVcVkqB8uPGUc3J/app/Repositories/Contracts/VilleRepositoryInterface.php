<?php

namespace App\Repositories\Contracts;

interface VilleRepositoryInterface extends BaseRepositoryInterface
{
    //
}
