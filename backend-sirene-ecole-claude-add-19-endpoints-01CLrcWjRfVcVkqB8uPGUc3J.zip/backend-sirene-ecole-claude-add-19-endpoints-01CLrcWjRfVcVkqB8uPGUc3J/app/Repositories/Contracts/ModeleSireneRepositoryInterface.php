<?php

namespace App\Repositories\Contracts;

interface ModeleSireneRepositoryInterface extends BaseRepositoryInterface
{
    //
}
