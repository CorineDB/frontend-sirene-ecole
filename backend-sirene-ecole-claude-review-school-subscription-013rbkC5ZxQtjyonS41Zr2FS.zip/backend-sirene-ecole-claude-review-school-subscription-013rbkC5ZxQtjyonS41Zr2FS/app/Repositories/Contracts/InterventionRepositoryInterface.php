<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface InterventionRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for InterventionRepository here if needed
}
