<?php

namespace App\Repositories\Contracts;

interface PaysRepositoryInterface extends BaseRepositoryInterface
{
    //
}
