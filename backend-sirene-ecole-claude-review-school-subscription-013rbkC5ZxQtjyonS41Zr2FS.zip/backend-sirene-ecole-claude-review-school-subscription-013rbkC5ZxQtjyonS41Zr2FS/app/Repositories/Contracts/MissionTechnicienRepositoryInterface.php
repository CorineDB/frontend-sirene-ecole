<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface MissionTechnicienRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for OrdreMissionRepository here if needed
}
