<?php

namespace App\Repositories\Contracts;

interface EcoleRepositoryInterface extends BaseRepositoryInterface
{
    
}
