<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface OrdreMissionRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for OrdreMissionRepository here if needed
}
