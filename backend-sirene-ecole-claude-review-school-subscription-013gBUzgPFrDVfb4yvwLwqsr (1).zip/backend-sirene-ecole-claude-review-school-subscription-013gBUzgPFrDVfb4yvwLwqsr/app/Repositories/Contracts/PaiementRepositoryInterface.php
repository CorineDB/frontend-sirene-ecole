<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface PaiementRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for PaiementRepository here if needed
}