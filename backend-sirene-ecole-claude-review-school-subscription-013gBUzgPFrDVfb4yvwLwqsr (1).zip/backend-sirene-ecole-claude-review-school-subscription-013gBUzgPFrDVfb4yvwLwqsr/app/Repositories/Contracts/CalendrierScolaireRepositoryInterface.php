<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface CalendrierScolaireRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for CalendrierScolaireRepository here if needed
}