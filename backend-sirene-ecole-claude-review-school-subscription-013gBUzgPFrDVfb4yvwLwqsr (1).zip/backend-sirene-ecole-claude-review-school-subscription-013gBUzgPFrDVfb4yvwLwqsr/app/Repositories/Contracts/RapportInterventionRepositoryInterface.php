<?php

namespace App\Repositories\Contracts;

use Illuminate\Database\Eloquent\Model;

interface RapportInterventionRepositoryInterface extends BaseRepositoryInterface
{
    // Add specific methods for RapportInterventionRepository here if needed
}
