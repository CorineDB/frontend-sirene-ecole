<?php

namespace App\Services\Contracts;

interface PaysServiceInterface extends BaseServiceInterface
{
    //
}
