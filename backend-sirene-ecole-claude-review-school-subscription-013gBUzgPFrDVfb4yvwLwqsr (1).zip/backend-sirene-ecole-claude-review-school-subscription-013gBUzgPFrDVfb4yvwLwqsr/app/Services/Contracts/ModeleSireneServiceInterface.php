<?php

namespace App\Services\Contracts;

interface ModeleSireneServiceInterface extends BaseServiceInterface
{
    //
}
